# CMake generated Testfile for 
# Source directory: /home/voidmain/projects/CS499-Capstone/CS300-capstone-after/CS-300-Project2/build-debug/_deps/googletest-src
# Build directory: /home/voidmain/projects/CS499-Capstone/CS300-capstone-after/CS-300-Project2/build-debug/_deps/googletest-build
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
subdirs("googlemock")
