file(REMOVE_RECURSE
  "CMakeFiles/tests.dir/link.d"
  "CMakeFiles/tests.dir/tests/bst_test.cpp.o"
  "CMakeFiles/tests.dir/tests/bst_test.cpp.o.d"
  "CMakeFiles/tests.dir/tests/csv_test.cpp.o"
  "CMakeFiles/tests.dir/tests/csv_test.cpp.o.d"
  "tests"
  "tests.pdb"
  "tests_e3b0c442_tests.cmake"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/tests.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
