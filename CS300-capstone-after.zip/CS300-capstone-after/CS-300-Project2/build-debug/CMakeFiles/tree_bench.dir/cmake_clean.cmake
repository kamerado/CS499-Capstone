file(REMOVE_RECURSE
  "CMakeFiles/tree_bench.dir/link.d"
  "CMakeFiles/tree_bench.dir/bench/tree_bench.cpp.o"
  "CMakeFiles/tree_bench.dir/bench/tree_bench.cpp.o.d"
  "tree_bench"
  "tree_bench.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/tree_bench.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
