file(REMOVE_RECURSE
  "CMakeFiles/catalog_lib.dir/src/csv.cpp.o"
  "CMakeFiles/catalog_lib.dir/src/csv.cpp.o.d"
  "CMakeFiles/catalog_lib.dir/src/helpers.cpp.o"
  "CMakeFiles/catalog_lib.dir/src/helpers.cpp.o.d"
  "libcatalog_lib.a"
  "libcatalog_lib.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/catalog_lib.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
