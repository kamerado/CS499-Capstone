# Empty compiler generated dependencies file for catalog_lib.
# This may be replaced when dependencies are built.
