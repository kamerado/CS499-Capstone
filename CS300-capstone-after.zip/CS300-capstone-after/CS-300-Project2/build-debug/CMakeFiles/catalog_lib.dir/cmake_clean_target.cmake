file(REMOVE_RECURSE
  "libcatalog_lib.a"
)
