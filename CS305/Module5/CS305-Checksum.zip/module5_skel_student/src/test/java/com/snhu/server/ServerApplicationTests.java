package com.snhu.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = com.snhu.sslserver.ServerApplication.class)
class ServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
