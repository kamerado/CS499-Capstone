package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.w3c.dom.Text;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;
import java.util.HexFormat;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController
class ServerController{
	private static String genChecksum(String text, String algo) {
		MessageDigest digest;
		try {
			digest = MessageDigest.getInstance(algo);
		} catch (NoSuchAlgorithmException e) {
			digest = null;
			return null;
		}
		byte[] hashBytes = digest.digest(text.getBytes(StandardCharsets.UTF_8));
		return HexFormat.of().formatHex(hashBytes);
		
	}
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Kameron Coolong!";
    	
    	String checksum = genChecksum(data, "SHA-256");
       
        return "<p>data:"+data+"<br/><br/>SHA-256 CheckSum Value:" + checksum;
    }
    
//    @RequestMapping("/error")
//    public String error(String errorMessage) {
//    	return errorMessage;
//    }
}
